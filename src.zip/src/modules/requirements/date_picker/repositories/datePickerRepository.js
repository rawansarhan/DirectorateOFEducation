'use strict'

const { Op } = require('sequelize')
const { likeContains } = require('../../../../core/utils/escapeLike')
const { DatePicker } = require('../../../../entities')

async function findById (id) {
  return DatePicker.findOne({
    where: { id, is_active: true }
  })
}

async function findByIdWidget (idWidget) {
  return DatePicker.findOne({
    where: { id_widget: idWidget, is_active: true }
  })
}

async function findAllActive () {
  return DatePicker.findAll({
    where: { is_active: true },
    order: [['id', 'ASC']]
  })
}

// جلب مع ترقيم صفحات وبحث. يُرجع { rows, count }.
async function findAndCountActive ({ limit, offset, search } = {}) {
  const where = { is_active: true }

  if (search) {
    const like = likeContains(search)
    where[Op.or] = [
      { label: like },
      { id_widget: like }
    ]
  }

  return DatePicker.findAndCountAll({
    where,
    order: [['id', 'ASC']],
    limit,
    offset
  })
}

async function create (data) {
  return DatePicker.create(data)
}

async function updateInstance (row, payload) {
  await row.update(payload)
  return row.reload()
}

module.exports = {
  findById,
  findByIdWidget,
  findAllActive,
  findAndCountActive,
  create,
  updateInstance
}
