'use strict'

const {
  findOrgDeptRole,
  getCitizenRole
} = require('../../../organization/public')
const orgDeptRoleRepository = require('../../../organization/role/repositories/orgDeptRoleRepository')

const {
  createStageConfigSchema
} = require('../validations/stageConfigValidations')

const {
  validateStageConfigJson
} = require('../validations/stageConfigSchema')

const stageRepository = require('../../processDefinition/repositories/stageRepository')

const stageConfigRepository = require('../repositories/stageConfigRepository')

const stageAssignmentRepository = require('../repositories/stageAssignmentRepository')

const stageConfigMapper = require('../mappers/stageConfigMapper')

const typeDocRepository = require('../../../requirements/typeDoc/repositories/typeDocRepository')

const processRepository =
  require('../../processDefinition/repositories/processRepository')

const { validateStageAction } = require('../../actions/actionHelpers')


const {
  getOrLoad,
  KEYS,
  invalidateStageConfig,
  invalidateStageAssignments,
  invalidateProcessDefinitionDetails
} = require('../../../../core/cache/apiCacheService')

const { API_CACHE_TTL_SECONDS } = require('../../../../core/config/env')

const {
  HTTP_STATUS,
  createHttpError
} = require('../../../../core/middleware/httpStatusCodes')

const { retryWithBackoff } = require('../../../../core/utils/retryWithBackoff')
const {
  resolveDatePickerBoundsInConfig
} = require('../../../../core/utils/dateBound')

function formatJoiError (error) {
  const lines = error.details.map(d => {
    const path = d.path.length ? d.path.join('.') : 'body'
    return `${path}: ${d.message}`
  })

  return `بيانات الطلب غير صالحة — ${lines.join(' | ')}`
}

function throwBusinessError (message, statusCode = HTTP_STATUS.BAD_REQUEST) {
  const err = createHttpError(message, statusCode, 'VALIDATION_ERROR')
  err.expose = true
  throw err
}

// 0 / '0' / null تعني "لا يوجد" عند البحث عن الدور (مؤسسة/قسم عامّ)
const normalizeOrgId = (v) => (v === 0 || v === '0' || v == null ? null : v)

function positiveIdOrNull (value) {
  if (value === 0 || value === '0' || value == null || value === '') {
    return null
  }

  const numeric = Number(value)
  return Number.isInteger(numeric) && numeric > 0 ? numeric : null
}

function coerceAssignmentItem (raw) {
  if (raw == null || typeof raw !== 'object' || Array.isArray(raw)) {
    return null
  }

  return {
    organization_id: positiveIdOrNull(
      raw.organization_id ?? raw.organizationId ?? raw.organization?.id
    ),
    department_id: positiveIdOrNull(
      raw.department_id ?? raw.departmentId ?? raw.department?.id
    ),
    role_id: positiveIdOrNull(
      raw.role_id ?? raw.roleId ?? raw.role?.id
    )
  }
}

function isNullStageAssignment (assignment = {}) {
  const organizationId = normalizeOrgId(assignment.organization_id)
  const departmentId = normalizeOrgId(assignment.department_id)
  const roleId = positiveIdOrNull(assignment.role_id)

  return organizationId == null && departmentId == null && roleId == null
}

/** CITIZEN في الداتا: مؤسسة/قسم null حتى لو role_id=2 */
function isCitizenLikeAssignment (assignment = {}) {
  return (
    normalizeOrgId(assignment.organization_id) == null &&
    normalizeOrgId(assignment.department_id) == null
  )
}

function assignmentKey (assignment = {}) {
  return [
    normalizeOrgId(assignment.organization_id) ?? 'null',
    normalizeOrgId(assignment.department_id) ?? 'null',
    positiveIdOrNull(assignment.role_id) ?? 'null'
  ].join('_')
}

function uniqueAssignments (items = []) {
  const seen = new Set()
  const unique = []

  for (const item of items) {
    if (!item) continue
    const key = assignmentKey(item)
    if (seen.has(key)) continue
    seen.add(key)
    unique.push(item)
  }

  return unique
}

/**
 * يرفع assignments من داخل config_json إن أُرسلت كمصفوفة ODR بالخطأ
 * (شائع مع is_assignment=true)، ويفضّل التعيين الفعلي على شكل CITIZEN
 * مثل `{ organization_id: null, department_id: null, role_id: 2 }`.
 */
function normalizeStageCreateItem (stage = {}) {
  const configJson = { ...(stage.config_json || {}) }
  const topLevel = Array.isArray(stage.assignments)
    ? stage.assignments.map(coerceAssignmentItem).filter(Boolean)
    : []
  const lifted = Array.isArray(configJson.assignments)
    ? configJson.assignments.map(coerceAssignmentItem).filter(Boolean)
    : []

  if (Array.isArray(configJson.assignments)) {
    delete configJson.assignments
  }

  const merged = uniqueAssignments([...topLevel, ...lifted])
  const concrete = merged.filter(item => !isCitizenLikeAssignment(item))
  const assignments = concrete.length ? concrete : merged

  return {
    ...stage,
    config_json: configJson,
    ...(assignments.length ? { assignments } : {})
  }
}

async function assertFilePickerTypeDocsExist (configJson = {}) {
  for (const widget of configJson.widgets || []) {
    if (widget.widget_type !== 'file_picker') {
      continue
    }

    const widgetId = widget.data?.id || 'file_picker'
    const typeDocId = Number(widget.data?.type_doc_id)

    if (!Number.isInteger(typeDocId) || typeDocId <= 0) {
      throwBusinessError(
        `الودجت "${widgetId}": type_doc_id مطلوب في file_picker`
      )
    }

    const typeDoc = await typeDocRepository.findById(typeDocId)

    if (!typeDoc) {
      throwBusinessError(
        `الودجت "${widgetId}": نوع الوثيقة (type_doc_id=${typeDocId}) غير موجود`
      )
    }

    if (typeDoc.is_active === false) {
      throwBusinessError(
        `الودجت "${widgetId}": نوع الوثيقة (type_doc_id=${typeDocId}) غير نشط`
      )
    }
  }
}

async function assertAssignmentsOptionsExist (stageId, assignmentsWidget) {
  const options = assignmentsWidget?.data?.options || []

  for (const option of options) {
    const key = String(option.key || '').trim()
    const orgDeptRole = await orgDeptRoleRepository.findActiveByCamundaGroupKey(key)

    if (!orgDeptRole) {
      throwBusinessError(
        `المرحلة ${stageId}: config_json.assignments — الخيار key="${key}" لا يطابق أي camunda_group_key نشط في organization_department_roles`
      )
    }
  }
}

// ======================================================
// CREATE STAGE CONFIG
// ======================================================

async function createStageConfigService (data) {
  // =====================================
  // NORMALIZE + VALIDATE config_json (widgets incl. file_picker.type_doc_id)
  // =====================================

  if (Array.isArray(data?.stages)) {
    data = {
      ...data,
      stages: data.stages.map(stage => {
        const normalized = normalizeStageCreateItem(stage)
        const { error, value } = validateStageConfigJson(
          normalized.config_json || {}
        )

        if (error) {
          throwBusinessError(formatJoiError(error))
        }

        return {
          ...normalized,
          config_json: value
        }
      })
    }
  }

  // =====================================
  // VALIDATION
  // =====================================

  const { error, value } = createStageConfigSchema.validate(data, {
    abortEarly: false,
    stripUnknown: true
  })

  if (error) {
    throwBusinessError(formatJoiError(error))
  }

  data = value

  // =====================================
  // LOAD STAGES ONCE
  // =====================================

  const stageIds = data.stages.map(s => s.stage_id)

  const stages = await stageRepository.findByIds(stageIds)

  const stageMap = new Map(stages.map(s => [s.id, s]))

  if (stages.length !== stageIds.length) {
    const found = new Set(stages.map(s => s.id))
    const missing = stageIds.filter(id => !found.has(id))
    throwBusinessError(
      `مرحلة غير موجودة: ${missing.join(', ')}`,
      HTTP_STATUS.NOT_FOUND
    )
  }

  const existingConfigs = await stageConfigRepository.findByStageIds(stageIds)

  if (existingConfigs.length > 0) {
    const taken = existingConfigs.map(c => c.stage_id).join(', ')
    throwBusinessError(
      `إعدادات المراحل التالية موجودة مسبقاً (stage_id): ${taken}`,
      HTTP_STATUS.CONFLICT
    )
  }

  // =====================================
  // LOAD EXISTING ASSIGNMENTS ONCE
  // =====================================

  const existingAssignments = await stageAssignmentRepository.findByStageIds(
    stageIds
  )

  const existingSet = new Set(
    existingAssignments.map(
      a => `${a.stage_id}_${a.organization_department_roles_id}`
    )
  )

  // =====================================
  // PREPARE BULK INSERTS
  // =====================================

  const configsToCreate = []

  const assignmentsToCreate = []

  const results = []

  // =====================================
  // LOOP STAGES
  // =====================================

  for (const item of data.stages) {
    const stage = stageMap.get(item.stage_id)

    const configActions = item.config_json?.actions

    if (stage.type === 'USER_TASK' && Array.isArray(configActions) && configActions.length) {
      throwBusinessError(
        `المرحلة ${item.stage_id}: actions لمهام USER_TASK تُرسل عند إكمال المهمة وليس في config_json`
      )
    }

    if (stage.type === 'SERVICE_TASK' && Array.isArray(configActions)) {
      for (const action of configActions) {
        const actionError = validateStageAction(action, item.stage_id)

        if (actionError) {
          throwBusinessError(actionError)
        }

        // SEND_NOTIFICATION: حوّل (organization_id, department_id, role_id)
        // إلى organization_department_roles_id ليعمل الإرسال الفعلي وقت التنفيذ
        if (action.name === 'SEND_NOTIFICATION') {
          const payload = action.payload || {}

          if (payload.role_id != null) {
            const orgDeptRole = await findOrgDeptRole({
              organization_id: normalizeOrgId(payload.organization_id),
              department_id: normalizeOrgId(payload.department_id),
              role_id: payload.role_id
            })

            if (!orgDeptRole) {
              throwBusinessError(
                `المرحلة ${item.stage_id}: SEND_NOTIFICATION — لم يتم العثور على دور (role_id=${payload.role_id}) للمؤسسة ${payload.organization_id} والقسم ${payload.department_id}`
              )
            }

            payload.to_organization_department_roles_id = orgDeptRole.id

            // نظّف الحقول المدخلة بعد تحويلها
            delete payload.organization_id
            delete payload.department_id
            delete payload.role_id

            action.payload = payload
          }
        }
      }
    }

    if (stage.type === 'USER_TASK') {
      const assignments = item.assignments || []

      if (!assignments.length) {
        throwBusinessError(
          `المرحلة ${item.stage_id} (USER_TASK): يجب تحديد assignments (مؤسسة/قسم/دور)`
        )
      }
    }

    await assertFilePickerTypeDocsExist(item.config_json)

    if (item.config_json?.assignments?.data?.options?.length) {
      await assertAssignmentsOptionsExist(item.stage_id, item.config_json.assignments)
    }

    // =================================
    // CONFIG
    // =================================

    configsToCreate.push({
      stage_id: item.stage_id,
      config_json: item.config_json
    })

    // =================================
    // USER TASK ASSIGNMENTS
    // =================================
    // is_assignment في config_json لا يغيّر سلوك الحفظ — يُخزَّن مثل باقي الحقول فقط.
    // USER_TASK: assignments مطلوبة وتُحفظ في stage_assignments كما أُرسلت.
    // SERVICE_TASK: لا تُرسل assignments
    // CITIZEN فقط عند organization_id=department_id=role_id=null صراحةً.

    const savedAssignments = []

    if (stage.type === 'USER_TASK') {
      const assignments = item.assignments || []
      const wantsDynamicAssignment = item.config_json?.is_assignment === true
      const hasConcreteAssignment = assignments.some(
        a => !isCitizenLikeAssignment(a)
      )

      if (wantsDynamicAssignment && assignments.length && !hasConcreteAssignment) {
        throwBusinessError(
          `المرحلة ${item.stage_id}: is_assignment=true يتطلب assignments فعلية ` +
          `{ organization_id, department_id, role_id } لمن يستلم هذه المرحلة — ` +
          `لا تُرسل شكل CITIZEN (organization_id/department_id = null أو role_id=2)`
        )
      }

      for (const a of assignments) {
        let orgDeptRole = null

        if (isCitizenLikeAssignment(a)) {
          orgDeptRole = await getCitizenRole()

          if (!orgDeptRole) {
            throwBusinessError(
              `المرحلة ${item.stage_id}: تعذّر إيجاد دور CITIZEN لتعيين organization_id/department_id/role_id = null`
            )
          }
        } else {
          const organizationId = normalizeOrgId(a.organization_id)
          const departmentId = normalizeOrgId(a.department_id)
          const roleId =
            a.role_id === 0 || a.role_id === '0' || a.role_id == null
              ? null
              : Number(a.role_id)

          if (roleId == null) {
            throwBusinessError(
              `المرحلة ${item.stage_id}: role_id مطلوب في assignments (أو أرسل الثلاثة null لتعيين CITIZEN)`
            )
          }

          // تعيين جزئي (مثلاً org/dept null مع role_id) يُحفظ كما هو عبر البحث — لا يُحوَّل لـ CITIZEN
          orgDeptRole = await findOrgDeptRole({
            organization_id: organizationId,
            department_id: departmentId,
            role_id: roleId
          })

          if (!orgDeptRole) {
            throwBusinessError(
              `لم يتم العثور على دور (role_id=${a.role_id}) للمؤسسة ${a.organization_id} والقسم ${a.department_id}`
            )
          }
        }

        const existingKey = `${stage.id}_${orgDeptRole.id}`

        if (existingSet.has(existingKey)) {
          savedAssignments.push({
            organization_id: orgDeptRole.organization_id ?? null,
            department_id: orgDeptRole.department_id ?? null,
            role_id: orgDeptRole.role_id ?? null,
            organization_department_roles_id: orgDeptRole.id
          })
          continue
        }

        assignmentsToCreate.push({
          stage_id: stage.id,
          organization_department_roles_id: orgDeptRole.id
        })

        existingSet.add(existingKey)

        savedAssignments.push({
          organization_id: orgDeptRole.organization_id ?? null,
          department_id: orgDeptRole.department_id ?? null,
          role_id: orgDeptRole.role_id ?? null,
          organization_department_roles_id: orgDeptRole.id
        })
      }
    }

    results.push({
      stage_id: stage.id,
      config: item.config_json,
      assignments: savedAssignments
    })
  }

  // =====================================
  // BULK CREATE CONFIGS
  // =====================================

  if (configsToCreate.length > 0) {
    try {
      await stageConfigRepository.bulkCreate(configsToCreate)
    } catch (dbErr) {
      dbErr.expose = true
      throw dbErr
    }

    const processIds = new Set(
      stages
        .map(s => s.process_definition_id)
        .filter(Boolean)
    )

    for (const processId of processIds) {
      await invalidateStageConfig(processId)
    }
  }

  // =====================================
  // BULK CREATE ASSIGNMENTS
  // =====================================

  if (assignmentsToCreate.length > 0) {
    await stageAssignmentRepository.bulkCreate(assignmentsToCreate)

    const affectedStageIds = [
      ...new Set(assignmentsToCreate.map(item => item.stage_id).filter(Boolean))
    ]

    for (const stageId of affectedStageIds) {
      await invalidateStageAssignments(stageId)
    }

    if (configsToCreate.length === 0) {
      const processIds = new Set(
        stages
          .map(s => s.process_definition_id)
          .filter(Boolean)
      )

      for (const processId of processIds) {
        await invalidateProcessDefinitionDetails(processId)
      }
    }
  }

  return {
    message: 'Stages configured successfully',

    data: stageConfigMapper.mapConfigs(results)
  }
}

// ======================================================
// GET AUTH STAGE CONFIG (مواطن / موظف — استمارة التقديم)
// ======================================================

async function loadAuthStageConfigPayload (numericProcessId) {
  const process = await processRepository.findById(numericProcessId)

  if (!process) {
    throw createHttpError(
      'تعريف العملية غير موجود — تحقق من معرّف العملية',
      HTTP_STATUS.NOT_FOUND,
      'NOT_FOUND'
    )
  }

  const stage = await stageRepository.findFirstAuthStage(numericProcessId)

  if (!stage) {
    throw createHttpError(
      'لا توجد مرحلة تقديم (AUTH) مرتبطة بهذه العملية',
      HTTP_STATUS.NOT_FOUND,
      'NOT_FOUND'
    )
  }

  const assignments = await stageAssignmentRepository.findByStageIds([stage.id])
  const stageConfig = await stageConfigRepository.findByStageId(stage.id)

  if (!stageConfig) {
    throw createHttpError(
      'لم تُكوَّن استمارة التقديم لهذه العملية بعد',
      HTTP_STATUS.NOT_FOUND,
      'NOT_FOUND'
    )
  }

  const configJson = stageConfig.config_json || {}
  let citizenConfig = configJson

  if (configJson.assignments) {
    const { assignments: _a, ...rest } = configJson
    citizenConfig = rest
  }

  return {
    config_json: citizenConfig,
    // للتحقق من الصلاحية خارج الكاش — لا يُعاد في الاستجابة
    assigned_odr_ids: (assignments || []).map(
      a => a.organization_department_roles_id
    )
  }
}

async function assertUserCanSubmitAuthStage (userId, assignedOdrIds = []) {
  if (!userId) {
    throw createHttpError(
      'Unauthorized',
      HTTP_STATUS.UNAUTHORIZED,
      'UNAUTHORIZED'
    )
  }

  const { getUserRoles } = require('../../../auth/public')
  const userOdrIds = await getUserRoles(userId)
  const assignedSet = new Set(
    (assignedOdrIds || [])
      .map(id => Number(id))
      .filter(id => Number.isInteger(id) && id > 0)
  )

  const hasAccess = (userOdrIds || []).some(id => assignedSet.has(Number(id)))

  if (!hasAccess) {
    throw createHttpError(
      'هذه المعاملة غير مخول لك التقديم عليها',
      HTTP_STATUS.FORBIDDEN,
      'FORBIDDEN'
    )
  }
}

async function getConfig_json (processId, { userId } = {}) {
  const numericProcessId = Number(processId)

  if (!Number.isInteger(numericProcessId) || numericProcessId < 1) {
    throw createHttpError(
      'معرّف العملية غير صالح — يجب أن يكون رقماً صحيحاً موجباً',
      HTTP_STATUS.BAD_REQUEST,
      'VALIDATION_ERROR'
    )
  }

  const data = await getOrLoad(
    KEYS.stageConfig(numericProcessId),
    () => retryWithBackoff(
      () => loadAuthStageConfigPayload(numericProcessId),
      { label: 'stageConfig.getConfig_json' }
    ),
    {
      label: `stage-config:process:${numericProcessId}`,
      ttlSeconds: API_CACHE_TTL_SECONDS
    }
  )

  await assertUserCanSubmitAuthStage(userId, data.assigned_odr_ids)

  const { assigned_odr_ids: _assigned, ...publicData } = data

  return {
    message: 'تم جلب إعدادات العملية بنجاح',
    data: {
      ...publicData,
      config_json: resolveDatePickerBoundsInConfig(publicData.config_json)
    }
  }
}
async function loadComplaintConfigPayload () {
  const activeComplaint = await processRepository.existsActiveComplaintProcess()

  if (!activeComplaint) {
    throw createHttpError(
      'لا توجد شكوى نشطة حالياً',
      HTTP_STATUS.NOT_FOUND,
      'NOT_FOUND'
    )
  }

  const stage = await stageRepository.findFirstAuthStage(activeComplaint.id)

  if (!stage) {
    throw createHttpError(
      'لا توجد مرحلة تقديم (AUTH) مرتبطة بعملية الشكوى',
      HTTP_STATUS.NOT_FOUND,
      'NOT_FOUND'
    )
  }

  const assignments = await stageAssignmentRepository.findByStageIds([stage.id])

  if (!assignments.length) {
    throw createHttpError(
      'لا توجد تعيينات لمرحلة التقديم في عملية الشكوى',
      HTTP_STATUS.NOT_FOUND,
      'NOT_FOUND'
    )
  }

  const stageConfig = await stageConfigRepository.findByStageId(stage.id)

  if (!stageConfig) {
    throw createHttpError(
      'لم تُكوَّن استمارة التقديم لعملية الشكوى بعد',
      HTTP_STATUS.NOT_FOUND,
      'NOT_FOUND'
    )
  }

  const configJson = stageConfig.config_json || {}
  let citizenConfig = configJson

  if (configJson.assignments) {
    const { assignments: _a, ...rest } = configJson
    citizenConfig = rest
  }

  return {
    process_definition_id: activeComplaint.id,
    process_name: activeComplaint.name,
    process_code: activeComplaint.code,
    assigned_odr_ids: assignments.map(a => a.organization_department_roles_id),
    config_json: citizenConfig
  }
}

async function getComplaintConfigForUser (userId) {
  const cacheKey = KEYS.complaintStageConfigActive()

  console.log(
    `[StageConfig] GET /api/stage_config/config/complaint — cache key: api:${cacheKey}`
  )

  const payload = await getOrLoad(
    cacheKey,
    () => retryWithBackoff(
      () => loadComplaintConfigPayload(),
      { label: 'stageConfig.getComplaintConfigForUser' }
    ),
    {
      label: 'stage-config:complaint:active',
      ttlSeconds: API_CACHE_TTL_SECONDS
    }
  )

  const { getUserRoles } = require('../../../auth/public')
  const userOdrIds = await getUserRoles(userId)
  const assignedOdrIds = new Set(payload.assigned_odr_ids || [])
  const hasAccess = userOdrIds.some(id => assignedOdrIds.has(id))

  if (!hasAccess) {
    throw createHttpError(
      'ليس لديك صلاحية تقديم شكوى — دورك غير مطابق لتعيينات مرحلة التقديم',
      HTTP_STATUS.FORBIDDEN,
      'FORBIDDEN'
    )
  }

  const { assigned_odr_ids: _assigned, ...data } = payload

  return {
    message: 'تم جلب استمارة الشكوى بنجاح',
    data: {
      ...data,
      config_json: resolveDatePickerBoundsInConfig(data.config_json)
    }
  }
}

module.exports = {
  createStageConfigService,
  getConfig_json,
  getComplaintConfigForUser
}
